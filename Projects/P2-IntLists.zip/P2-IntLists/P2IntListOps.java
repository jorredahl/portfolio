// CS 201 Project 2 Problem 1
// Name: 

public class P2IntListOps extends IntListOps {

    // Tackle one at a time! Test using
    // "java P2IntListOpsTest"

    public static boolean isSorted(IntList L) {

        return true; // just a placeholder

    }

    public static IntList remove(int i, IntList L) {

        return empty(); // just a placeholder

    }

    public static IntList removeDuplicates(IntList L) {

        return empty(); // just a placeholder

    }

}
